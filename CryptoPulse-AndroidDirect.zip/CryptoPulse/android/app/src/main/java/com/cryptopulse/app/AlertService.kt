package com.cryptopulse.app

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class AlertService : Service() {
    companion object {
        const val CHANNEL = "cryptopulse_alerts"
        const val STATUS_CHANNEL = "cryptopulse_status"
        const val CMC_KEY = "cmc_api_key"
        private const val WS_URL = "wss://ws-feed.exchange.coinbase.com"
        private const val PRODUCTS_URL = "https://api.exchange.coinbase.com/products?quote_currency=USD&limit=1000"
        private const val CMC_URL = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?start=1&limit=5000&convert=USD"
        private const val THRESHOLD = 50.0
        private const val SAMPLE_MS = 1000L
        private const val HISTORY_MS = 5 * 60 * 1000L + 5000L
        private const val COOLDOWN_MS = 60_000L
    }

    private data class Tick(val time: Long, val price: Double)
    private val history = HashMap<String, ArrayDeque<Tick>>()
    private val lastAlert = HashMap<String, Long>()
    private var ws: WebSocket? = null
    private var lastSampleSecond = -1L
    private var latest = HashMap<String, Double>()
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(7, foregroundNotification("در حال دریافت قیمت‌های USD از Coinbase…"))
        loadProductsAndConnect()
    }

    private fun loadProductsAndConnect() {
        val req = Request.Builder().url(PRODUCTS_URL).get().build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) { reconnectLater() }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) { reconnectLater(); return }
                    val arr = JSONArray(it.body?.string() ?: "[]")
                    val ids = ArrayList<String>()
                    for (i in 0 until arr.length()) {
                        val p = arr.getJSONObject(i)
                        if (p.optString("quote_currency") == "USD" && p.optString("status", "online") == "online") {
                            val id = p.optString("id")
                            if (id.isNotBlank()) ids.add(id)
                        }
                    }
                    if (ids.isNotEmpty()) connect(ids) else reconnectLater()
                }
            }
        })
    }

    private fun connect(productIds: List<String>) {
        ws?.close(1000, "reconnect")
        val subscribe = JSONObject().apply {
            put("type", "subscribe")
            put("product_ids", JSONArray(productIds))
            put("channels", JSONArray().apply { put("ticker") })
        }
        val request = Request.Builder().url(WS_URL).build()
        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(subscribe.toString()) }
            override fun onMessage(webSocket: WebSocket, text: String) { handleTicker(text) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { reconnectLater() }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { reconnectLater() }
        })
    }

    private fun handleTicker(text: String) {
        try {
            val j = JSONObject(text)
            if (j.optString("type") != "ticker") return
            val product = j.optString("product_id")
            val price = j.optDouble("price", Double.NaN)
            if (product.isBlank() || !price.isFinite() || price <= 0.0) return
            latest[product] = price
            val sec = System.currentTimeMillis() / 1000L
            if (sec != lastSampleSecond) {
                lastSampleSecond = sec
                sampleAll()
            }
        } catch (_: Exception) { }
    }

    private fun sampleAll() {
        val now = System.currentTimeMillis()
        for ((symbol, price) in latest) {
            val q = history.getOrPut(symbol) { ArrayDeque() }
            q.addLast(Tick(now, price))
            while (q.isNotEmpty() && now - q.first.time > HISTORY_MS) q.removeFirst()
            checkWindow(symbol, q, now, 1_000L, "1s")
            checkWindow(symbol, q, now, 60_000L, "1m")
            checkWindow(symbol, q, now, 180_000L, "3m")
            checkWindow(symbol, q, now, 300_000L, "5m")
        }
    }

    private fun checkWindow(symbol: String, q: ArrayDeque<Tick>, now: Long, window: Long, tf: String) {
        if (q.size < 2) return
        val target = now - window
        var base: Tick? = null
        for (tick in q) {
            if (tick.time <= target) base = tick else break
        }
        if (base == null) return
        val current = q.last.price
        val change = (current - base.price) / base.price * 100.0
        if (abs(change) < THRESHOLD) return
        val direction = if (change > 0) "PUMP" else "DUMP"
        val key = "$symbol|$tf|$direction"
        val previous = lastAlert[key] ?: 0L
        if (now - previous < COOLDOWN_MS) return
        lastAlert[key] = now
        notifyAlert(symbol, tf, direction, change, current)
    }

    private fun notifyAlert(symbol: String, tf: String, direction: String, change: Double, price: Double) {
        val title = if (direction == "PUMP") "🚀 PUMP  $symbol" else "🔻 DUMP  $symbol"
        val body = String.format(Locale.US, "%+.2f%% | %s | Price: %s USD", change, tf, formatPrice(price))
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify((System.nanoTime() and 0x7fffffff).toInt(), n)
    }

    private fun formatPrice(p: Double): String = when {
        p >= 1 -> String.format(Locale.US, "%.6f", p)
        p >= 0.000001 -> String.format(Locale.US, "%.10f", p)
        else -> String.format(Locale.US, "%.12g", p)
    }

    private fun foregroundNotification(text: String) = NotificationCompat.Builder(this, STATUS_CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_info_details)
        .setContentTitle("CryptoPulse")
        .setContentText(text)
        .setOngoing(true)
        .build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pump/Dump Alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(STATUS_CHANNEL, "Monitor Status", NotificationManager.IMPORTANCE_LOW))
    }

    private fun reconnectLater() {
        android.os.Handler(mainLooper).postDelayed({ loadProductsAndConnect() }, 5000L)
    }

    override fun onDestroy() { ws?.close(1000, "service stopped"); client.dispatcher.executorService.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
