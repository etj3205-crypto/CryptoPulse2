package com.cryptopulse.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        if (Build.VERSION.SDK_INT >= 31) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.FOREGROUND_SERVICE), 11)

        val title = TextView(this).apply { text = "CryptoPulse\nUSD Pump/Dump Monitor"; textSize = 24f; setPadding(32,48,32,24) }
        val info = TextView(this).apply { text = "مانیتور مستقیم روی گوشی\nWebSocket: Coinbase USD pairs\nتایم‌فریم‌ها: 1s / 1m / 3m / 5m\nآستانه: ±50%"; textSize = 16f; setPadding(32,8,32,24) }
        val status = TextView(this).apply { text = "خاموش"; textSize = 16f; setPadding(32,8,32,24) }
        val start = Button(this).apply {
            text = "▶ شروع مانیتور"
            setOnClickListener {
                ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, AlertService::class.java))
                status.text = "فعال — برنامه را می‌توانی ببندی؛ سرویس پس‌زمینه ادامه دارد."
            }
        }
        val stop = Button(this).apply {
            text = "■ توقف"
            setOnClickListener { stopService(Intent(this@MainActivity, AlertService::class.java)); status.text = "خاموش" }
        }
        val note = TextView(this).apply {
            text = "توجه: برای کارکرد لحظه‌ای، اینترنت گوشی باید وصل باشد. در حالت آفلاین داده جدید قابل دریافت نیست."
            setPadding(32,24,32,16)
        }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(title); addView(info); addView(status); addView(start); addView(stop); addView(note) })
    }
}
