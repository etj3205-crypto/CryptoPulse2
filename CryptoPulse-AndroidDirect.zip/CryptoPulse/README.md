# CryptoPulse — Android Direct Monitor

نسخه بدون VPS. سرویس مانیتور مستقیماً روی گوشی Android اجرا می‌شود.

## منطق
- دریافت فهرست جفت‌های USD از Coinbase Exchange REST
- اتصال مستقیم به Coinbase WebSocket ticker
- نمونه‌برداری ۱ ثانیه‌ای از قیمت
- محاسبه تغییرات 1s / 1m / 3m / 5m
- هشدار در صورت رسیدن به +50% یا -50%
- Notification با نام جفت، درصد تغییر، تایم‌فریم و قیمت USD
- Foreground Service برای ادامه کار پس از بسته شدن UI
- reconnect خودکار پس از قطع WebSocket
- cooldown یک دقیقه‌ای برای جلوگیری از اسپم

## نکته CoinMarketCap
CoinMarketCap برای پوشش/اطلاعات بازار می‌تواند به‌عنوان لایه metadata اضافه شود، اما برای قیمت ۱ ثانیه‌ای باید از WebSocket صرافی استفاده شود. قرار دادن CMC API key داخل APK امنیت کامل ندارد؛ نسخه بعدی می‌تواند کلید را از کاربر بگیرد و در Android Keystore نگهداری کند.

## ساخت APK
پروژه `android/` را با Android Studio باز کن و Build > Build APK(s) را بزن.

این پروژه برای Android 8+ و target SDK 35 تنظیم شده است.
