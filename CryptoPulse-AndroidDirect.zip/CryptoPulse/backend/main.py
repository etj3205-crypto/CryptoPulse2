import asyncio, json, os, time
from collections import defaultdict, deque
from typing import Dict, Deque, Tuple, Set

import httpx
import websockets
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect

load_dotenv()
CMC_API_KEY = os.getenv("CMC_API_KEY", "")
THRESHOLD = float(os.getenv("ALERT_THRESHOLD", "50"))
ALLOW_STABLE = os.getenv("ALLOW_STABLECOIN_QUOTES", "false").lower() == "true"

app = FastAPI(title="CryptoPulse")
clients: Set[WebSocket] = set()
# symbol -> deque[(unix_seconds, price, source)]
history: Dict[str, Deque[Tuple[float, float, str]]] = defaultdict(lambda: deque(maxlen=600))
last_alert: Dict[Tuple[str, str], float] = {}

# Exact USD pairs. Stablecoin quotes are opt-in.
def allowed_quote(q: str) -> bool:
    return q == "USD" or (ALLOW_STABLE and q in {"USDT", "USDC"})


def pct(old: float, new: float) -> float:
    return (new - old) / old * 100 if old else 0.0


def symbol_key(base: str, quote: str) -> str:
    return f"{base.upper()}/{quote.upper()}"

async def broadcast(alert):
    dead = []
    msg = json.dumps(alert)
    for ws in list(clients):
        try:
            await ws.send_text(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)

async def ingest(base: str, quote: str, price: float, source: str):
    if not allowed_quote(quote) or price <= 0:
        return
    now = time.time()
    key = symbol_key(base, quote)
    h = history[key]
    h.append((now, price, source))
    windows = {"1s": 1, "1m": 60, "3m": 180, "5m": 300}
    for tf, seconds in windows.items():
        target = now - seconds
        old = next((x for x in h if x[0] <= target), None)
        if not old:
            continue
        change = pct(old[1], price)
        if abs(change) >= THRESHOLD:
            alert_key = (key, tf)
            # debounce same symbol/timeframe for 30 seconds
            if now - last_alert.get(alert_key, 0) < 30:
                continue
            last_alert[alert_key] = now
            direction = "PUMP" if change > 0 else "DUMP"
            await broadcast({
                "type": "ALERT", "direction": direction, "symbol": key,
                "timeframe": tf, "change_pct": round(change, 3),
                "price": price, "source": source, "ts": now
            })

async def coinbase_loop():
    # Coinbase public websocket; dynamically subscribe to USD products from CMC discovery.
    while True:
        try:
            products = await get_usd_products()
            if not products:
                await asyncio.sleep(60); continue
            uri = "wss://advanced-trade-ws.coinbase.com"
            async with websockets.connect(uri, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                ids = products[:300]
                await ws.send(json.dumps({"type":"subscribe","product_ids":ids,"channel":"ticker","jwt":""}))
                async for raw in ws:
                    data = json.loads(raw)
                    events = data.get("events", [])
                    for ev in events:
                        for t in ev.get("tickers", []):
                            product = t.get("product_id", "")
                            if "-USD" not in product: continue
                            base, quote = product.split("-", 1)
                            await ingest(base, quote, float(t.get("price", 0)), "coinbase")
        except Exception:
            await asyncio.sleep(5)

async def get_usd_products():
    # CMC is used to validate active symbols; Coinbase product discovery is public.
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get("https://api.exchange.coinbase.com/products")
            r.raise_for_status()
            data = r.json()
            products = []
            for p in data:
                if p.get("quote_currency") == "USD" and p.get("status") == "online":
                    products.append(p["id"])
            return products
    except Exception:
        return []

async def cmc_loop():
    # Periodic USD reference refresh. This is not used for 1-second detection.
    if not CMC_API_KEY:
        return
    while True:
        try:
            headers = {"X-CMC_PRO_API_KEY": CMC_API_KEY}
            async with httpx.AsyncClient(timeout=20) as c:
                await c.get("https://pro-api.coinmarketcap.com/v3/cryptocurrency/listings/latest",
                            params={"start":1,"limit":5000,"convert":"USD"}, headers=headers)
        except Exception:
            pass
        await asyncio.sleep(60)

@app.on_event("startup")
async def startup():
    asyncio.create_task(coinbase_loop())
    asyncio.create_task(cmc_loop())

@app.get("/health")
async def health():
    return {"ok": True, "symbols_tracked": len(history), "threshold": THRESHOLD}

@app.websocket("/ws/alerts")
async def alerts(ws: WebSocket):
    await ws.accept(); clients.add(ws)
    try:
        await ws.send_text(json.dumps({"type":"STATUS","message":"CryptoPulse connected","threshold":THRESHOLD}))
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        clients.discard(ws)
    except Exception:
        clients.discard(ws)
